<?php include 'header.php'; ?>
<?php include 'category.php'; ?>
<head>
	<title>Unauthorized</title>
</head>
<div id="index" class="span7">
	<div id="resourceinfo">
		<div id="resourcetitle">Sorry, bad deal</div>
		<div id="resourcedescription">
You are not authorized to view that page.
		</div>
	</div>

<?php include 'footer.php'; ?>
