<?php include 'header.php'; ?>
<?php include 'category.php'; ?>
<head>
	<title>Contact</title>
</head>
<div id="right" class="span7">
	<h2>Contact Us</h2>
	<p>If you would like to contact us, please fill out the form below or use the following.</p>
	<p>
	  <b>Some entity</b><br>
	  Some address<br>
	</p>
	<form id='contact-us'>
	  <div class=field>Name:</div>
	  <input type=text></input> 
	  <div class=field>Email address:</div>
	  <input type=text></input> 
	  <div class=field>Message:</div>
	  <textarea name=message></textarea> 
	</form>
</div>

<?php include 'footer.php'; ?>
