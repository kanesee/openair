<?php include 'header.php'; ?>
<?php include 'category.php'; ?>
<head>
	<title>Donations</title>
</head>
<div id="right" class="span7">
  <h2>Donations</h2>
  Please help us pay for this site!
</div>

<?php include 'footer.php'; ?>