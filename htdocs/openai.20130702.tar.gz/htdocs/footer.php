    </div>
  </div>
<div class='row-fluid'>
	<div id='footer' class="span12">
		Copyright &copy; 2013, InferLink Corporation.  All rights reserved.
	</div>
</div>

</body>
</html>

<?php ob_flush() ?>